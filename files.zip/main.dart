// lib/main.dart

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:timezone/data/latest.dart' as tz_data;
import 'package:intl/date_symbol_data_local.dart';
import 'services/background_service.dart';
import 'services/alarm_service.dart';
import 'services/notification_service.dart';
import 'ui/home_screen.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();

  // Lock orientasi ke portrait
  await SystemChrome.setPreferredOrientations([
    DeviceOrientation.portraitUp,
    DeviceOrientation.portraitDown,
  ]);

  // Init timezone data
  tz_data.initializeTimeZones();

  // Init locale Indonesia
  await initializeDateFormatting('id_ID', null);

  // Init notification service
  await NotificationService.initialize();

  // Init alarm service (set timezone lokal)
  await AlarmService.initialize();

  // Mulai background service
  await BackgroundServiceManager.initialize();

  // Request permission notifikasi
  await NotificationService.requestPermission();

  runApp(const PrayerAlarmApp());
}

class PrayerAlarmApp extends StatelessWidget {
  const PrayerAlarmApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Prayer Alarm',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        colorScheme: ColorScheme.fromSeed(
          seedColor: const Color(0xFFD4AF37),
          brightness: Brightness.dark,
        ),
        useMaterial3: true,
      ),
      home: const HomeScreen(),
    );
  }
}
