// lib/services/alarm_service.dart
//
// LOGIKA ALARM:
// Setiap sholat memiliki 2 alarm:
//   [1] 10 menit SEBELUM waktu masuk sholat  → "Segera sholat X"
//   [2] 10 menit SEBELUM waktu sholat HABIS  → "Waktu X hampir habis"

import 'package:timezone/timezone.dart' as tz;
import 'package:timezone/data/latest.dart' as tz_data;
import 'package:flutter_timezone/flutter_timezone.dart';
import 'package:vibration/vibration.dart';
import '../models/prayer_time.dart';
import 'notification_service.dart';

class AlarmService {
  static const _minutesBefore = 10;

  /// ID range untuk alarm:
  /// Sholat index 0-4, alarm type 0=masuk 1=habis
  /// ID = (sholatIndex * 10) + alarmType
  /// Jadi ID: 0,1, 10,11, 20,21, 30,31, 40,41
  static int _alarmId(int sholatIndex, int alarmType) =>
      (sholatIndex * 10) + alarmType;

  static Future<void> initialize() async {
    tz_data.initializeTimeZones();
    final timezoneName = await FlutterTimezone.getLocalTimezone();
    tz.setLocalLocation(tz.getLocation(timezoneName));
    await NotificationService.initialize();
  }

  /// Schedule semua alarm untuk hari ini berdasarkan jadwal sholat
  static Future<void> scheduleAllAlarms(PrayerTimes prayerTimes) async {
    // Batalkan semua alarm lama dulu
    await NotificationService.cancelAll();

    final prayers = prayerTimes.allPrayers;
    final now = DateTime.now();

    for (int i = 0; i < prayers.length; i++) {
      final prayer = prayers[i];

      // Parse waktu
      final startTime = _parseTime(prayer.start);
      final endTime = _parseTime(prayer.end);

      // Alarm 1: 10 menit sebelum waktu masuk
      final alarm1 = startTime.subtract(const Duration(minutes: _minutesBefore));
      if (alarm1.isAfter(now)) {
        await NotificationService.scheduleNotification(
          id: _alarmId(i, 0),
          title: '${prayer.iconEmoji} ${prayer.name} dalam $_minutesBefore menit',
          body:
              'Waktu ${prayer.name} (${prayer.arabicName}) akan masuk pukul ${prayer.start}. Siapkan diri untuk sholat.',
          scheduledTime: alarm1,
          payload: 'prayer_start_${prayer.name}',
        );
      }

      // Alarm 2: 10 menit sebelum waktu sholat habis
      final alarm2 = endTime.subtract(const Duration(minutes: _minutesBefore));
      if (alarm2.isAfter(now)) {
        await NotificationService.scheduleNotification(
          id: _alarmId(i, 1),
          title: '⚠️ Waktu ${prayer.name} hampir habis!',
          body:
              'Waktu sholat ${prayer.name} (${prayer.arabicName}) akan berakhir pukul ${prayer.end}. Segera sholat!',
          scheduledTime: alarm2,
          payload: 'prayer_end_${prayer.name}',
        );
      }
    }
  }

  /// Parse "HH:mm" menjadi DateTime hari ini
  static DateTime _parseTime(String timeStr) {
    // AlAdhan kadang mengembalikan "05:21 (WIB)" — strip timezone suffix
    final clean = timeStr.split(' ').first.trim();
    final parts = clean.split(':');
    final hour = int.parse(parts[0]);
    final minute = int.parse(parts[1]);
    final now = DateTime.now();
    return DateTime(now.year, now.month, now.day, hour, minute);
  }

  /// Getarkan HP saat alarm trigger
  static Future<void> vibrate() async {
    final hasVibrator = await Vibration.hasVibrator() ?? false;
    if (!hasVibrator) return;

    // Pola getaran: panjang-pendek-panjang (mirip pola adzan)
    await Vibration.vibrate(
      pattern: [0, 800, 200, 800, 200, 1200],
      intensities: [0, 200, 0, 200, 0, 255],
    );
  }

  /// Batalkan semua alarm
  static Future<void> cancelAll() async {
    await NotificationService.cancelAll();
  }

  /// Hitung sholat berikutnya dari jadwal hari ini
  static PrayerEntry? getNextPrayer(PrayerTimes prayerTimes) {
    final now = DateTime.now();
    for (final prayer in prayerTimes.allPrayers) {
      final startTime = _parseTime(prayer.start);
      if (startTime.isAfter(now)) return prayer;
    }
    return null;
  }

  /// Hitung durasi countdown ke sholat berikutnya
  static Duration? getTimeUntilNextPrayer(PrayerTimes prayerTimes) {
    final next = getNextPrayer(prayerTimes);
    if (next == null) return null;
    final startTime = _parseTime(next.start);
    return startTime.difference(DateTime.now());
  }
}
