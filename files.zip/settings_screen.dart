// lib/ui/settings_screen.dart

import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:shared_preferences/shared_preferences.dart';
import '../services/location_service.dart';
import '../services/alarm_service.dart';

class SettingsScreen extends StatefulWidget {
  const SettingsScreen({super.key});

  @override
  State<SettingsScreen> createState() => _SettingsScreenState();
}

class _SettingsScreenState extends State<SettingsScreen> {
  bool _soundEnabled = true;
  bool _vibrationEnabled = true;
  bool _notificationsEnabled = true;
  int _minutesBefore = 10;
  String _calculationMethod = '11'; // Kemenag Indonesia

  final _methods = {
    '11': 'Kemenag Indonesia',
    '2': 'Muslim World League',
    '3': 'Egyptian Authority',
    '4': 'Umm Al-Qura (Mekkah)',
    '1': 'University of Islamic Sciences, Karachi',
  };

  @override
  void initState() {
    super.initState();
    _loadSettings();
  }

  Future<void> _loadSettings() async {
    final prefs = await SharedPreferences.getInstance();
    setState(() {
      _soundEnabled = prefs.getBool('sound_enabled') ?? true;
      _vibrationEnabled = prefs.getBool('vibration_enabled') ?? true;
      _notificationsEnabled = prefs.getBool('notifications_enabled') ?? true;
      _minutesBefore = prefs.getInt('minutes_before') ?? 10;
      _calculationMethod = prefs.getString('calculation_method') ?? '11';
    });
  }

  Future<void> _saveSettings() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setBool('sound_enabled', _soundEnabled);
    await prefs.setBool('vibration_enabled', _vibrationEnabled);
    await prefs.setBool('notifications_enabled', _notificationsEnabled);
    await prefs.setInt('minutes_before', _minutesBefore);
    await prefs.setString('calculation_method', _calculationMethod);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFF0D1B2A),
      appBar: AppBar(
        backgroundColor: const Color(0xFF1A3A5C),
        title: Text(
          'Pengaturan',
          style: GoogleFonts.nunito(
            color: Colors.white,
            fontWeight: FontWeight.bold,
          ),
        ),
        iconTheme: const IconThemeData(color: Colors.white),
      ),
      body: ListView(
        padding: const EdgeInsets.all(20),
        children: [
          _sectionTitle('Alarm'),
          _buildCard([
            _buildSwitch(
              'Suara Adzan',
              'Putar adzan saat alarm',
              Icons.volume_up,
              _soundEnabled,
              (v) => setState(() => _soundEnabled = v),
            ),
            _buildSwitch(
              'Getaran',
              'Getar saat alarm berbunyi',
              Icons.vibration,
              _vibrationEnabled,
              (v) => setState(() => _vibrationEnabled = v),
            ),
            _buildSwitch(
              'Notifikasi',
              'Tampilkan notifikasi push',
              Icons.notifications,
              _notificationsEnabled,
              (v) => setState(() => _notificationsEnabled = v),
            ),
          ]),
          const SizedBox(height: 16),
          _sectionTitle('Waktu Pengingat'),
          _buildCard([
            Padding(
              padding: const EdgeInsets.all(16),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    'Ingatkan $_minutesBefore menit sebelumnya',
                    style: GoogleFonts.nunito(
                      color: Colors.white,
                      fontSize: 15,
                      fontWeight: FontWeight.w600,
                    ),
                  ),
                  Slider(
                    value: _minutesBefore.toDouble(),
                    min: 5,
                    max: 30,
                    divisions: 5,
                    activeColor: const Color(0xFFD4AF37),
                    inactiveColor: Colors.white24,
                    label: '$_minutesBefore menit',
                    onChanged: (v) =>
                        setState(() => _minutesBefore = v.round()),
                  ),
                ],
              ),
            ),
          ]),
          const SizedBox(height: 16),
          _sectionTitle('Metode Perhitungan'),
          _buildCard([
            Padding(
              padding: const EdgeInsets.all(8),
              child: Column(
                children: _methods.entries.map((e) {
                  return RadioListTile<String>(
                    title: Text(
                      e.value,
                      style: GoogleFonts.nunito(
                        color: Colors.white,
                        fontSize: 14,
                      ),
                    ),
                    value: e.key,
                    groupValue: _calculationMethod,
                    activeColor: const Color(0xFFD4AF37),
                    onChanged: (v) =>
                        setState(() => _calculationMethod = v!),
                  );
                }).toList(),
              ),
            ),
          ]),
          const SizedBox(height: 16),
          _sectionTitle('Lokasi'),
          _buildCard([
            ListTile(
              leading: const Icon(Icons.location_off, color: Color(0xFFD4AF37)),
              title: Text(
                'Reset Cache Lokasi',
                style: GoogleFonts.nunito(color: Colors.white),
              ),
              subtitle: Text(
                'Paksa deteksi ulang GPS',
                style: GoogleFonts.nunito(color: Colors.white54, fontSize: 12),
              ),
              trailing: const Icon(Icons.chevron_right, color: Colors.white38),
              onTap: () async {
                await LocationService.clearCache();
                if (mounted) {
                  ScaffoldMessenger.of(context).showSnackBar(
                    const SnackBar(content: Text('Cache lokasi dihapus')),
                  );
                }
              },
            ),
            ListTile(
              leading: const Icon(Icons.alarm_off, color: Colors.redAccent),
              title: Text(
                'Batalkan Semua Alarm',
                style: GoogleFonts.nunito(color: Colors.redAccent),
              ),
              onTap: () async {
                await AlarmService.cancelAll();
                if (mounted) {
                  ScaffoldMessenger.of(context).showSnackBar(
                    const SnackBar(content: Text('Semua alarm dibatalkan')),
                  );
                }
              },
            ),
          ]),
          const SizedBox(height: 24),
          SizedBox(
            width: double.infinity,
            child: ElevatedButton(
              onPressed: () async {
                await _saveSettings();
                if (mounted) {
                  ScaffoldMessenger.of(context).showSnackBar(
                    const SnackBar(
                      content: Text('✅ Pengaturan disimpan'),
                      backgroundColor: Color(0xFF1A5C3A),
                    ),
                  );
                }
              },
              style: ElevatedButton.styleFrom(
                backgroundColor: const Color(0xFFD4AF37),
                foregroundColor: Colors.black,
                padding: const EdgeInsets.symmetric(vertical: 16),
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(12),
                ),
              ),
              child: Text(
                'Simpan Pengaturan',
                style: GoogleFonts.nunito(
                  fontWeight: FontWeight.bold,
                  fontSize: 16,
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _sectionTitle(String title) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 8, left: 4),
      child: Text(
        title.toUpperCase(),
        style: GoogleFonts.nunito(
          color: const Color(0xFFD4AF37),
          fontSize: 12,
          fontWeight: FontWeight.w700,
          letterSpacing: 1.5,
        ),
      ),
    );
  }

  Widget _buildCard(List<Widget> children) {
    return Container(
      decoration: BoxDecoration(
        color: const Color(0xFF162233),
        borderRadius: BorderRadius.circular(16),
      ),
      child: Column(children: children),
    );
  }

  Widget _buildSwitch(
    String title,
    String subtitle,
    IconData icon,
    bool value,
    ValueChanged<bool> onChanged,
  ) {
    return SwitchListTile(
      secondary: Icon(icon, color: const Color(0xFFD4AF37)),
      title: Text(
        title,
        style: GoogleFonts.nunito(color: Colors.white, fontSize: 15),
      ),
      subtitle: Text(
        subtitle,
        style: GoogleFonts.nunito(color: Colors.white54, fontSize: 12),
      ),
      value: value,
      activeColor: const Color(0xFFD4AF37),
      onChanged: onChanged,
    );
  }
}
