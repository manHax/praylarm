// lib/services/background_service.dart
//
// Background service berjalan terus di background untuk:
// 1. Deteksi lokasi setiap pagi jam 03:00
// 2. Refresh jadwal sholat dari API
// 3. Re-schedule semua alarm untuk hari ini
// 4. Update homescreen widget

import 'dart:async';
import 'dart:ui';
import 'package:flutter_background_service/flutter_background_service.dart';
import 'package:flutter_background_service_android/flutter_background_service_android.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'location_service.dart';
import 'prayer_api_service.dart';
import 'alarm_service.dart';
import 'home_widget_service.dart';

class BackgroundServiceManager {
  static Future<void> initialize() async {
    final service = FlutterBackgroundService();

    await service.configure(
      // ── Android ───────────────────────────────────────────────────────────
      androidConfiguration: AndroidConfiguration(
        onStart: onStart,
        autoStart: true,
        isForegroundMode: true,
        notificationChannelId: 'prayer_bg_service',
        initialNotificationTitle: '🕌 Prayer Alarm Aktif',
        initialNotificationContent: 'Memantau jadwal sholat...',
        foregroundServiceNotificationId: 999,
      ),
      // ── iOS ───────────────────────────────────────────────────────────────
      iosConfiguration: IosConfiguration(
        autoStart: true,
        onForeground: onStart,
        onBackground: onIosBackground,
      ),
    );

    await service.startService();
  }

  /// Entry point untuk background isolate (harus top-level function)
  @pragma('vm:entry-point')
  static Future<void> onStart(ServiceInstance service) async {
    DartPluginRegistrant.ensureInitialized();

    if (service is AndroidServiceInstance) {
      service.on('setAsForeground').listen((_) {
        service.setAsForegroundService();
      });
      service.on('setAsBackground').listen((_) {
        service.setAsBackgroundService();
      });
    }

    service.on('stopService').listen((_) {
      service.stopSelf();
    });

    // Inisialisasi alarm service (timezone)
    await AlarmService.initialize();

    // Jalankan refresh pertama kali saat service start
    await _refreshPrayerSchedule(service);

    // Jadwalkan refresh setiap hari jam 03:00 dini hari
    // Cek setiap 30 menit apakah sudah saatnya refresh
    Timer.periodic(const Duration(minutes: 30), (_) async {
      final now = DateTime.now();

      // Refresh di antara jam 03:00–03:30
      if (now.hour == 3 && now.minute < 30) {
        await _refreshPrayerSchedule(service);
      }

      // Update notifikasi foreground dengan sholat berikutnya
      if (service is AndroidServiceInstance) {
        await _updateForegroundNotification(service);
      }
    });
  }

  static Future<void> _refreshPrayerSchedule(ServiceInstance service) async {
    try {
      // 1. Ambil lokasi
      final location = await LocationService.getLocationSilently();
      if (location == null) return;

      // 2. Ambil jadwal sholat
      final prayerTimes = await PrayerApiService.getPrayerTimes(
        lat: location.lat,
        lng: location.lng,
      );

      // 3. Schedule semua alarm
      await AlarmService.scheduleAllAlarms(prayerTimes);

      // 4. Update homescreen widget
      await HomeWidgetService.update(prayerTimes);

      // 5. Simpan timestamp terakhir refresh
      final prefs = await SharedPreferences.getInstance();
      await prefs.setInt(
        'last_refresh',
        DateTime.now().millisecondsSinceEpoch,
      );

      // Kirim event ke UI jika app sedang terbuka
      service.invoke('prayerTimesUpdated', prayerTimes.toJson());
    } catch (e) {
      // Silent fail — akan dicoba lagi 30 menit kemudian
    }
  }

  static Future<void> _updateForegroundNotification(
      AndroidServiceInstance service) async {
    try {
      final prefs = await SharedPreferences.getInstance();
      final location = await LocationService.getLocationSilently();
      if (location == null) return;

      final prayerTimes = await PrayerApiService.getPrayerTimes(
        lat: location.lat,
        lng: location.lng,
      );

      final next = AlarmService.getNextPrayer(prayerTimes);
      final duration = AlarmService.getTimeUntilNextPrayer(prayerTimes);

      if (next != null && duration != null) {
        final hours = duration.inHours;
        final minutes = duration.inMinutes % 60;
        final countdownStr = hours > 0
            ? '$hours jam $minutes menit'
            : '$minutes menit';

        service.setForegroundNotificationInfo(
          title: '🕌 Prayer Alarm Aktif',
          content:
              '${next.iconEmoji} ${next.name} pukul ${next.start} (dalam $countdownStr)',
        );
      }
    } catch (_) {}
  }

  /// iOS background handler
  @pragma('vm:entry-point')
  static Future<bool> onIosBackground(ServiceInstance service) async {
    DartPluginRegistrant.ensureInitialized();
    return true;
  }

  /// Panggil dari UI untuk memaksa refresh jadwal
  static Future<void> forceRefresh() async {
    final service = FlutterBackgroundService();
    service.invoke('forceRefresh');
  }

  static Future<bool> isRunning() async {
    return FlutterBackgroundService().isRunning();
  }
}
