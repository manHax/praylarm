// lib/services/prayer_api_service.dart

import 'dart:convert';
import 'package:http/http.dart' as http;
import 'package:shared_preferences/shared_preferences.dart';
import '../models/prayer_time.dart';

class PrayerApiService {
  static const _baseUrl = 'https://api.aladhan.com/v1';
  static const _cacheKey = 'cached_prayer_times';
  static const _cacheDateKey = 'cached_prayer_date';

  // Method 11 = Kemenag Indonesia (Kementerian Agama)
  // Ganti ke 2 untuk Muslim World League jika di luar Indonesia
  static const _method = 11;

  /// Ambil jadwal sholat untuk hari ini berdasarkan koordinat
  static Future<PrayerTimes> getPrayerTimes({
    required double lat,
    required double lng,
    DateTime? date,
  }) async {
    final targetDate = date ?? DateTime.now();
    final dateStr =
        '${targetDate.day.toString().padLeft(2, '0')}-${targetDate.month.toString().padLeft(2, '0')}-${targetDate.year}';

    // Cek cache (hanya cache untuk hari ini)
    final cached = await _getCached(dateStr);
    if (cached != null) return cached;

    // Fetch dari API
    final url = Uri.parse(
      '$_baseUrl/timings/$dateStr'
      '?latitude=$lat'
      '&longitude=$lng'
      '&method=$_method'
      '&school=1', // school=1 → Syafi'i (umum di Indonesia)
    );

    final response = await http.get(url).timeout(const Duration(seconds: 10));

    if (response.statusCode != 200) {
      throw Exception('Gagal mengambil jadwal sholat: ${response.statusCode}');
    }

    final json = jsonDecode(response.body) as Map<String, dynamic>;
    if (json['code'] != 200) {
      throw Exception('API error: ${json['status']}');
    }

    final prayerTimes = PrayerTimes.fromJson(json);
    await _cache(prayerTimes, dateStr);
    return prayerTimes;
  }

  /// Ambil jadwal sholat besok (untuk schedule alarm malam hari)
  static Future<PrayerTimes> getTomorrowPrayerTimes({
    required double lat,
    required double lng,
  }) async {
    final tomorrow = DateTime.now().add(const Duration(days: 1));
    return getPrayerTimes(lat: lat, lng: lng, date: tomorrow);
  }

  static Future<PrayerTimes?> _getCached(String dateStr) async {
    try {
      final prefs = await SharedPreferences.getInstance();
      final cachedDate = prefs.getString(_cacheDateKey);
      if (cachedDate != dateStr) return null;

      final cachedJson = prefs.getString(_cacheKey);
      if (cachedJson == null) return null;

      final map = jsonDecode(cachedJson) as Map<String, dynamic>;
      return PrayerTimes.fromJson({'data': _reconstructApiFormat(map)});
    } catch (_) {
      return null;
    }
  }

  static Future<void> _cache(PrayerTimes pt, String dateStr) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString(_cacheDateKey, dateStr);
    await prefs.setString(_cacheKey, jsonEncode(pt.toJson()));
  }

  static Map<String, dynamic> _reconstructApiFormat(Map<String, dynamic> map) {
    return {
      'timings': {
        'Fajr': map['fajr'],
        'Sunrise': map['sunrise'],
        'Dhuhr': map['dhuhr'],
        'Asr': map['asr'],
        'Maghrib': map['maghrib'],
        'Isha': map['isha'],
        'Midnight': map['midnight'],
      },
      'date': {'readable': map['date']},
      'meta': {
        'latitude': map['latitude'],
        'longitude': map['longitude'],
        'timezone': map['timezone'],
      },
    };
  }
}
