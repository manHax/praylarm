// lib/services/location_service.dart

import 'package:geolocator/geolocator.dart';
import 'package:shared_preferences/shared_preferences.dart';

class LocationService {
  static const _latKey = 'cached_lat';
  static const _lngKey = 'cached_lng';
  static const _timeKey = 'cached_location_time';
  static const _cacheHours = 6; // cache lokasi 6 jam

  /// Ambil lokasi terkini, dengan fallback ke cache jika GPS gagal
  static Future<({double lat, double lng})> getCurrentLocation() async {
    // 1. Cek cache dulu
    final cached = await _getCachedLocation();
    if (cached != null) return cached;

    // 2. Cek & minta permission
    LocationPermission permission = await Geolocator.checkPermission();
    if (permission == LocationPermission.denied) {
      permission = await Geolocator.requestPermission();
    }
    if (permission == LocationPermission.deniedForever) {
      throw Exception('Izin lokasi ditolak permanen. Buka Settings untuk mengaktifkan.');
    }

    // 3. Ambil posisi
    final position = await Geolocator.getCurrentPosition(
      locationSettings: const LocationSettings(
        accuracy: LocationAccuracy.medium, // hemat baterai
        timeLimit: Duration(seconds: 15),
      ),
    );

    // 4. Simpan ke cache
    await _cacheLocation(position.latitude, position.longitude);

    return (lat: position.latitude, lng: position.longitude);
  }

  /// Ambil lokasi tanpa menampilkan dialog permission (untuk background service)
  static Future<({double lat, double lng})?> getLocationSilently() async {
    try {
      final permission = await Geolocator.checkPermission();
      if (permission == LocationPermission.denied ||
          permission == LocationPermission.deniedForever) {
        return await _getCachedLocation();
      }

      final position = await Geolocator.getCurrentPosition(
        locationSettings: const LocationSettings(
          accuracy: LocationAccuracy.medium,
          timeLimit: Duration(seconds: 10),
        ),
      );
      await _cacheLocation(position.latitude, position.longitude);
      return (lat: position.latitude, lng: position.longitude);
    } catch (_) {
      return await _getCachedLocation();
    }
  }

  static Future<({double lat, double lng})?> _getCachedLocation() async {
    final prefs = await SharedPreferences.getInstance();
    final lat = prefs.getDouble(_latKey);
    final lng = prefs.getDouble(_lngKey);
    final time = prefs.getInt(_timeKey);

    if (lat == null || lng == null || time == null) return null;

    final cached = DateTime.fromMillisecondsSinceEpoch(time);
    final diff = DateTime.now().difference(cached);
    if (diff.inHours >= _cacheHours) return null;

    return (lat: lat, lng: lng);
  }

  static Future<void> _cacheLocation(double lat, double lng) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setDouble(_latKey, lat);
    await prefs.setDouble(_lngKey, lng);
    await prefs.setInt(_timeKey, DateTime.now().millisecondsSinceEpoch);
  }

  /// Hapus cache lokasi (paksa refresh)
  static Future<void> clearCache() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.remove(_latKey);
    await prefs.remove(_lngKey);
    await prefs.remove(_timeKey);
  }
}
