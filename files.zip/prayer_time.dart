// lib/models/prayer_time.dart

class PrayerTimes {
  final String fajr;
  final String sunrise;
  final String dhuhr;
  final String asr;
  final String maghrib;
  final String isha;
  final String midnight;
  final String date;
  final double latitude;
  final double longitude;
  final String timezone;

  const PrayerTimes({
    required this.fajr,
    required this.sunrise,
    required this.dhuhr,
    required this.asr,
    required this.maghrib,
    required this.isha,
    required this.midnight,
    required this.date,
    required this.latitude,
    required this.longitude,
    required this.timezone,
  });

  factory PrayerTimes.fromJson(Map<String, dynamic> json) {
    final timings = json['data']['timings'] as Map<String, dynamic>;
    final meta = json['data']['meta'] as Map<String, dynamic>;
    final date = json['data']['date']['readable'] as String;

    return PrayerTimes(
      fajr: timings['Fajr'] as String,
      sunrise: timings['Sunrise'] as String,
      dhuhr: timings['Dhuhr'] as String,
      asr: timings['Asr'] as String,
      maghrib: timings['Maghrib'] as String,
      isha: timings['Isha'] as String,
      midnight: timings['Midnight'] as String,
      date: date,
      latitude: (meta['latitude'] as num).toDouble(),
      longitude: (meta['longitude'] as num).toDouble(),
      timezone: meta['timezone'] as String,
    );
  }

  Map<String, dynamic> toJson() => {
        'fajr': fajr,
        'sunrise': sunrise,
        'dhuhr': dhuhr,
        'asr': asr,
        'maghrib': maghrib,
        'isha': isha,
        'midnight': midnight,
        'date': date,
        'latitude': latitude,
        'longitude': longitude,
        'timezone': timezone,
      };

  /// Mengembalikan list [nama, waktu_mulai, waktu_akhir] untuk semua sholat
  List<PrayerEntry> get allPrayers => [
        PrayerEntry(name: 'Fajr', start: fajr, end: sunrise),
        PrayerEntry(name: 'Dhuhr', start: dhuhr, end: asr),
        PrayerEntry(name: 'Asr', start: asr, end: maghrib),
        PrayerEntry(name: 'Maghrib', start: maghrib, end: isha),
        PrayerEntry(name: 'Isha', start: isha, end: midnight),
      ];
}

class PrayerEntry {
  final String name;
  final String start; // format "HH:mm"
  final String end;   // format "HH:mm"

  const PrayerEntry({
    required this.name,
    required this.start,
    required this.end,
  });

  String get arabicName {
    const map = {
      'Fajr': 'الفجر',
      'Dhuhr': 'الظهر',
      'Asr': 'العصر',
      'Maghrib': 'المغرب',
      'Isha': 'العشاء',
    };
    return map[name] ?? name;
  }

  String get iconEmoji {
    const map = {
      'Fajr': '🌙',
      'Dhuhr': '☀️',
      'Asr': '🌤️',
      'Maghrib': '🌅',
      'Isha': '🌃',
    };
    return map[name] ?? '🕌';
  }
}
